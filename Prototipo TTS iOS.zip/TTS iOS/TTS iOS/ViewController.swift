//
//  ViewController.swift
//  TTS iOS
//
//  Created by Javier González on 3/5/17.
//  Copyright © 2017 Javier González. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    
    @IBOutlet var Etiqueta: UILabel!
    //Etiqueta donde se almacena la selección del Picker
    
    @IBOutlet var Texto: UITextView!
    //Texto donde el usuario escribe
    
    @IBOutlet var Lenguaje: UIPickerView!
    var array_lenguajes = ["Español","Inglés", "Francés", "Alemán"]
    //Picker que almacena los idiomas y array de idiomas que se muestran
    
    @IBOutlet var Slider: UISlider!
    //Slider de selección de velocidad
    
    @IBOutlet var Boton: UIButton!
    //Boton de Hablar.
    
    
    
    
    
    //Funcion que oculta el teclado y nos muestra la vista
    func dismissKeyboard() {
        view.endEditing(true)
    }
    
    //Funciones Delegate del Picker
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return array_lenguajes.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return array_lenguajes[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        Etiqueta.text = array_lenguajes [row]
    }
    //Funcion que almacena en una etiqueta el lenguaje seleccionado
    
    
    
    
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.dismissKeyboard))
        
        view.addGestureRecognizer(tap)
        //Ver y almacenar si en algun momento se toca la pantalla para ocultar el teclado
        
        
        self.Lenguaje.dataSource = self
        self.Lenguaje.delegate = self
        
        Etiqueta.isHidden = true //Oculta la etiqueta donde se escribe el texto del picker
        //para posteriormente almacenarlo como variable.
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    @IBAction func hablar(_ sender: Any) {
        //Acción pulsar boton - Hablar
        
        
        let texto = AVSpeechUtterance(string: Texto.text!)
        //Cogemos texto del cuadro de texto
        
        let idioma = AVSpeechUtterance(string: Etiqueta.text!)
        //Cogemos de la etiqueta el idioma seleccionado
        
        
        if (idioma.speechString == "Español"){
            texto.voice = AVSpeechSynthesisVoice (language: "es-ES")
            
        }
        if (idioma.speechString == "Inglés"){
            texto.voice = AVSpeechSynthesisVoice (language: "en-US")
            
        }
        if (idioma.speechString == "Francés"){
            texto.voice = AVSpeechSynthesisVoice (language: "fr-FR")
            
        }
        if (idioma.speechString == "Alemán"){
            texto.voice = AVSpeechSynthesisVoice (language: "de-DE")
            
        }
        //Sentencias IF correspondientes a decir el Texto con el idioma seleccionado
        
        
        texto.rate = Slider.value;
        //A Texto se le da la velocidad indicada en el Slider, en .rate
        
        let sintetizador = AVSpeechSynthesizer()
        //Creacion de sintetizador
        
        sintetizador.speak(texto)
        //El sintetizador dice ese texto con las características que le hemos dado

    }
    
    
    
    
    
    
    
    


}

